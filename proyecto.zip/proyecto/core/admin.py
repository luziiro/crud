from django.contrib import admin
from .models import Categoria, Juego

# Register your models here.
admin.site.register(Categoria)
admin.site.register(Juego)